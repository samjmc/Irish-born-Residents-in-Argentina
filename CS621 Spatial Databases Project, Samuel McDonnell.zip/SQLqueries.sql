--SLIDE 13
--How many crimes happened in comunas 1 and 3 in 2016?
SELECT COUNT(*) FROM p230056."crimesbsas"
WHERE (comuna = 1) OR (comuna = 3)

-- What percentage of overall crimes happened in comunas 1 and 3
WITH total_count AS (SELECT COUNT(*) FROM p230056."crimesbsas"),
     c1and3_count AS (SELECT COUNT(*) FROM p230056."crimesbsas" WHERE (comuna = 1) OR (comuna = 3))
SELECT c1and3_count.count * 100 / total_count.count AS percentage
FROM total_count, c1and3_count;

--SLIDE 14
-- How many crimes happen within the cluster area around Estacion Once?
WITH convex_hull AS (
  SELECT ST_ConvexHull(ST_Collect(wkb_geometry)) AS geom FROM p230056."crimesbsas"
),
polygon_points AS (
    SELECT ST_MakePolygon(ST_GeomFromText('LINESTRING(-58.40693129669597 -34.603403001907836, 
										  -58.408072393149226 -34.610140752530285, 
										  -58.40516507783855 -34.61042658445003, 
										  -58.40406367169642 -34.60372152869457, 
										  -58.40693129669597 -34.603403001907836)', 4326)) as geom
),
within_points AS (
    SELECT COUNT(*) FROM p230056."crimesbsas"
    WHERE ST_Within(wkb_geometry, (SELECT geom FROM polygon_points) ) 
)

SELECT within_points.count as count FROM within_points;

--SLIDE 15
-- What is the count of crimes for each comuna?
SELECT comuna, COUNT(*) as total_count
FROM p230056."crimesbsas"
GROUP BY comuna
ORDER BY total_count DESC;

--SLIDE 19
--Rank the comunas based on a combined ranking of income and education levels.
WITH 
  ranked_income AS (
    SELECT 
      rank() OVER (ORDER BY "Income per household" DESC) as income_rank,
      *
    FROM p230056."IncomeBSAS"
  ),
  ranked_education AS (
    SELECT 
      rank() OVER (ORDER BY "Seconday or More Completed" DESC) as education_rank,
      *
    FROM p230056."EducationBSAS"
  )
SELECT 
  ranked_income.id, 
  (income_rank + education_rank) / 2.0 as avg_rank,
  rank() OVER (ORDER BY (income_rank + education_rank) / 2.0) as overall_rank
FROM 
  ranked_income
  JOIN ranked_education ON ranked_income.id = ranked_education.id
ORDER BY 
  overall_rank;
  
-- Comunas 14, 13, 2 are most likely to be settled in by Irish, based on income and education.
-- Comunas 4, 8, 9 are least likely to be settled in by Irish, based on income and education.

-- SLIDE 20
-- How many and which railway lines intersect the 3 highest ranked comunas?

SELECT 
  distinct comunas.comunas as comuna_number,
  railways.name as railway_name
FROM 
  comunas, railways 
  where (railways.name is not null) 
  and (st_intersects(comunas.wkb_geometry, railways.wkb_geometry)) 
  and ((comunas.comunas = 14) or (comunas.comunas = 13) or (comunas.comunas = 2))
  
-- How many railway lines intersect the 3 lowest ranked comunas?

SELECT 
  distinct comunas.comunas as comuna_number,
  railways.name as railway_name
FROM 
  comunas, railways 
  where (railways.name is not null) 
  and (st_contains(comunas.wkb_geometry, railways.wkb_geometry)) 
  and ((comunas.comunas = 4) or (comunas.comunas = 8) or (comunas.comunas = 9))
  
  
-- What about just the 2 lowest ranked comunas?
SELECT 
  distinct comunas.comunas as comuna_number,
  railways.name as railway_name
FROM 
  comunas, railways 
  where (railways.name is not null) 
  and (st_contains(comunas.wkb_geometry, railways.wkb_geometry)) 
  and ((comunas.comunas = 8) or (comunas.comunas = 9))
  


  
  
